# Kodi Radio Station

## Version 1.1.6

This build intentionally removes the experimental external Winamp/VLC radio
streaming work.

The add-on is restored to the stable web-focused architecture:

- public now-playing page
- browser audio streaming
- artwork
- Kodi metadata
- Album Info
- admin controls
- responsive UI
- LAN access controls

No `/radio`, `/radio.mp3`, `/radio.m3u`, or `/radio.pls` endpoints are included.

This version is based directly on the known-good 1.0.4 baseline.


## Reverse proxy deployment

Version 1.1.7 adds trusted-proxy-aware client IP handling for the admin access
restriction.

Default trusted proxies:

    127.0.0.1,::1

This is appropriate when the HTTPS reverse proxy runs on the same machine as
Kodi Radio Station.

The reverse proxy should send:

    Host: radio.example.com
    X-Forwarded-Proto: https
    X-Forwarded-For: <real client chain>

`X-Forwarded-For` is ignored unless the immediate TCP peer matches the
**Trusted reverse proxy addresses** setting.

For `/stream`, preserve Range requests and disable proxy buffering/caching.


## 1.1.8 default port

The default Kodi Radio Station HTTP port is now:

    8000

Typical reverse-proxy backend:

    http://127.0.0.1:8000/

Public URL example:

    https://radio.example.com/


## Compact embedded player

Version 1.1.9 adds a second, independent player page:

    /compact

The existing full player at `/` is unchanged.

The compact player is designed for an iframe at the top of another website. It
uses a single horizontal card approximately 104px tall and includes album art,
track title, album, artist, genre, Album Info, and a small play/pause control.

Only `/compact` is frameable. The rest of Kodi Radio Station retains its
existing `X-Frame-Options: DENY` protection.

Example:

    <iframe
        src="https://radio.example.com/compact"
        title="Radio"
        style="width:100%;height:112px;border:0;"
        allow="autoplay">
    </iframe>


## 1.2.0 Album Info behavior

`Album Info` is now TheAudioDB-only.

The add-on no longer falls back to MusicBrainz under any circumstance. If
TheAudioDB cannot resolve the current artist/album pair, the Album Info request
returns a not-found response instead of redirecting to another provider.


## 1.2.1 Winamp compatibility test

This version adds an isolated first-stage Winamp test without changing the
working web player.

Current MP3:

    /current.mp3

Winamp playlist:

    /winamp.pls

M3U playlist:

    /winamp.m3u

Diagnostic endpoint:

    /api/winamp-debug

`/current.mp3` is intentionally a normal HTTP MP3 object. It starts from the
beginning of the current song unless the player sends an HTTP Range request.

This stage is only intended to prove that Winamp can open and play audio from
the Kodi Radio Station add-on. Live synchronization and track following are not
part of this version.


## 1.2.3 live Winamp stream

The previous `/current.mp3` endpoint is intentionally static and remains
available for diagnostics.

A new endpoint now provides the Kodi-following stream:

    /live.mp3

The Winamp playlists now point to `/live.mp3`:

    /winamp.pls
    /winamp.m3u

Behavior:

- starts near Kodi's current playback position
- MP3 frame-aligns the initial join point
- pauses when Kodi pauses
- follows subsequent MP3 tracks
- stops when Kodi playback stops or Kodi becomes unavailable
- no extra listening port is introduced; everything remains on the add-on's
  existing HTTP port


## 1.2.5 Winamp now-playing title

When the client requests ICY metadata, `/live.mp3` now sends:

    Station Name - Artist Name - Song Name

The station-name portion comes from the existing Station name setting in the
Kodi Radio Station add-on.

A short initial audio burst is also sent before normal pacing begins. This is
intended to keep Winamp's input buffer healthy and reduce repeated switching
between the song title and its "Buffering" display.

No additional port is used.


## 1.2.6 Winamp title cleanup

Winamp now receives the ICY StreamTitle in this exact format:

    StationTitle-ArtistName-SongName

There are no spaces around the hyphens.

The static station title was also removed from the PLS/M3U playlist metadata.
That prevents Winamp from displaying the station name again in parentheses after
the dynamic ICY title.


## 1.2.7 Winamp parenthetical station-name fix

Winamp was appending the ICY station name in parentheses after the dynamic
StreamTitle. The `/live.mp3` response no longer sends `icy-name` or
`icy-description`.

The displayed dynamic title remains exactly:

    StationTitle-ArtistName-SongName

Example:

    Kodi Radio Station-LCD Soundsystem-Someone Great


## 1.2.8 Winamp source-name suffix cleanup

Winamp was falling back to the stream URL basename and displaying `(live.mp3)`
after the dynamic ICY title.

The PLS and M3U files now explicitly provide a blank stream title so the dynamic
ICY `StreamTitle` remains authoritative.

Expected display:

    StationTitle-ArtistName-SongName


## 1.2.9 Winamp buffering reduction

Winamp's `Buffering` text is generated by Winamp itself, so the server cannot
literally disable that UI message. This build minimizes how often it appears by:

- sending roughly eight seconds of audio immediately at connection/track change;
- sending ICY metadata after only 4096 audio bytes so the song title appears
  sooner;
- maintaining a small 3% delivery margin above the estimated source bitrate to
  reduce buffer underruns.

The now-playing format remains:

    StationTitle-ArtistName-SongName

## Release numbering

This package is the **public 1.0.0 release**.

Kodi's internal add-on version is **1.2.10** so it can be installed over the
previous working 1.2.9 development build without Kodi treating the release as
a downgrade. Functionally, the runtime code is the proven 1.2.9 baseline.

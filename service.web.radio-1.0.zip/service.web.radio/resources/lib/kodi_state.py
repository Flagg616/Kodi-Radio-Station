# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import sqlite3
import urllib.parse
from pathlib import Path

import xbmc
import xbmcvfs


def _json_rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params

    raw = xbmc.executeJSONRPC(json.dumps(request))
    response = json.loads(raw)
    if "error" in response:
        raise RuntimeError("Kodi JSON-RPC error: {}".format(response["error"]))
    return response.get("result")


def _seconds(time_obj):
    if not isinstance(time_obj, dict):
        return 0.0
    return (
        int(time_obj.get("hours", 0)) * 3600
        + int(time_obj.get("minutes", 0)) * 60
        + int(time_obj.get("seconds", 0))
        + int(time_obj.get("milliseconds", 0)) / 1000.0
    )


def _first(value, default=""):
    if isinstance(value, list):
        return value[0] if value else default
    return value if value not in (None, "") else default


def get_status():
    active = _json_rpc("Player.GetActivePlayers") or []
    audio = next((p for p in active if p.get("type") == "audio"), None)

    try:
        app_props = _json_rpc(
            "Application.GetProperties",
            {"properties": ["volume", "muted"]},
        ) or {}
    except Exception:
        app_props = {}

    if not audio:
        return {
            "playing": False,
            "paused": False,
            "title": "",
            "artist": "",
            "album": "",
            "genre": "",
            "position": 0.0,
            "duration": 0.0,
            "percentage": 0.0,
            "thumbnail": "",
            "file": "",
            "stream_available": False,
            "stream_token": "",
            "volume": int(app_props.get("volume", 0) or 0),
            "muted": bool(app_props.get("muted", False)),
            "shuffle": False,
            "repeat": "off",
        }

    player_id = audio["playerid"]

    item_result = _json_rpc(
        "Player.GetItem",
        {
            "playerid": player_id,
            "properties": [
                "title", "artist", "album", "genre", "thumbnail",
                "duration", "file"
            ],
        },
    ) or {}

    props = _json_rpc(
        "Player.GetProperties",
        {
            "playerid": player_id,
            "properties": [
                "time", "totaltime", "percentage", "speed",
                "shuffled", "repeat"
            ],
        },
    ) or {}

    item = item_result.get("item", {})
    position = _seconds(props.get("time"))
    duration = _seconds(props.get("totaltime"))

    if not duration:
        try:
            duration = float(item.get("duration", 0) or 0)
        except (TypeError, ValueError):
            duration = 0.0

    media_file = item.get("file") or ""
    token_basis = "{}|{}|{}|{}".format(
        media_file,
        item.get("title") or item.get("label") or "",
        _first(item.get("artist")),
        item.get("album") or "",
    )
    try:
        import hashlib
        stream_token = hashlib.sha1(token_basis.encode("utf-8", "ignore")).hexdigest()[:16]
    except Exception:
        stream_token = str(abs(hash(token_basis)))

    return {
        "playing": True,
        "paused": int(props.get("speed", 0) or 0) == 0,
        "title": item.get("title") or item.get("label") or "",
        "artist": _first(item.get("artist")),
        "album": item.get("album") or "",
        "genre": _first(item.get("genre")),
        "position": round(position, 3),
        "duration": round(duration, 3),
        "percentage": round(float(props.get("percentage", 0.0) or 0.0), 3),
        "thumbnail": item.get("thumbnail") or "",
        "file": media_file,
        "stream_available": bool(media_file),
        "stream_token": stream_token,
        "volume": int(app_props.get("volume", 0) or 0),
        "muted": bool(app_props.get("muted", False)),
        "shuffle": bool(props.get("shuffled", False)),
        "repeat": props.get("repeat", "off") or "off",
    }


def get_audio_player_id():
    active = _json_rpc("Player.GetActivePlayers") or []
    audio = next((p for p in active if p.get("type") == "audio"), None)
    return audio.get("playerid") if audio else None


def admin_action(action, value=None):
    player_id = get_audio_player_id()

    if action == "playpause":
        if player_id is None:
            raise RuntimeError("No active audio player")
        return _json_rpc("Player.PlayPause", {"playerid": player_id})

    if action == "stop":
        if player_id is None:
            return None
        return _json_rpc("Player.Stop", {"playerid": player_id})

    if action in ("next", "previous"):
        if player_id is None:
            raise RuntimeError("No active audio player")
        return _json_rpc(
            "Player.GoTo",
            {"playerid": player_id, "to": action},
        )

    if action == "seek":
        if player_id is None:
            raise RuntimeError("No active audio player")
        try:
            percentage = float(value)
        except (TypeError, ValueError):
            raise ValueError("Invalid seek percentage")
        percentage = max(0.0, min(100.0, percentage))
        return _json_rpc(
            "Player.Seek",
            {"playerid": player_id, "value": percentage},
        )

    if action == "volume":
        try:
            volume = int(round(float(value)))
        except (TypeError, ValueError):
            raise ValueError("Invalid volume")
        volume = max(0, min(100, volume))
        return _json_rpc("Application.SetVolume", {"volume": volume})

    if action == "mute":
        return _json_rpc("Application.SetMute", {"mute": "toggle"})

    if action == "shuffle":
        if player_id is None:
            raise RuntimeError("No active audio player")
        return _json_rpc(
            "Player.SetShuffle",
            {"playerid": player_id, "shuffle": "toggle"},
        )

    if action == "repeat":
        if player_id is None:
            raise RuntimeError("No active audio player")
        mode = str(value or "off")
        if mode not in ("off", "one", "all"):
            raise ValueError("Invalid repeat mode")
        return _json_rpc(
            "Player.SetRepeat",
            {"playerid": player_id, "repeat": mode},
        )

    raise ValueError("Unknown admin action")

def _unwrap_image_url(image_url):
    if not image_url or not image_url.startswith("image://"):
        return image_url or ""

    wrapped = image_url[len("image://"):]
    if wrapped.endswith("/"):
        wrapped = wrapped[:-1]

    decoded = urllib.parse.unquote(wrapped)

    if decoded.startswith(("music@", "video@")):
        return ""

    return decoded


def _read_vfs_file(path):
    if not path:
        return None

    handle = None
    try:
        handle = xbmcvfs.File(path, "rb")
        data = handle.readBytes()
        if data:
            return data
    except Exception:
        pass
    finally:
        try:
            if handle:
                handle.close()
        except Exception:
            pass

    return None


def _candidate_texture_databases():
    candidates = []

    for special_dir in (
        "special://database/",
        "special://profile/Database/",
        "special://masterprofile/Database/",
    ):
        try:
            directory = xbmcvfs.translatePath(special_dir)
            if not directory or not os.path.isdir(directory):
                continue
            for name in os.listdir(directory):
                if name.startswith("Textures") and name.endswith(".db"):
                    path = os.path.join(directory, name)
                    if path not in candidates:
                        candidates.append(path)
        except Exception:
            continue

    def version_key(path):
        name = os.path.basename(path)
        digits = "".join(ch for ch in name if ch.isdigit())
        return int(digits or 0)

    return sorted(candidates, key=version_key, reverse=True)


def _cachedurl_from_texture_db(image_url):
    if not image_url:
        return ""

    lookup_urls = [image_url]
    decoded = _unwrap_image_url(image_url)
    if decoded and decoded not in lookup_urls:
        lookup_urls.append(decoded)

    for db_path in _candidate_texture_databases():
        conn = None
        try:
            uri = Path(db_path).resolve().as_uri() + "?mode=ro"
            conn = sqlite3.connect(uri, uri=True, timeout=0.25)

            for lookup in lookup_urls:
                row = conn.execute(
                    "SELECT cachedurl FROM texture WHERE url = ? "
                    "ORDER BY id DESC LIMIT 1",
                    (lookup,),
                ).fetchone()
                if row and row[0]:
                    return str(row[0])
        except Exception:
            continue
        finally:
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

    return ""


def _read_cached_artwork(image_url):
    cachedurl = _cachedurl_from_texture_db(image_url)
    if cachedurl:
        for base in (
            "special://masterprofile/Thumbnails/",
            "special://profile/Thumbnails/",
        ):
            data = _read_vfs_file(base + cachedurl.replace("\\", "/"))
            if data:
                return data

    try:
        cache_name = xbmc.getCacheThumbName(image_url)
    except Exception:
        cache_name = ""

    if cache_name:
        stem = os.path.splitext(cache_name)[0]
        bucket = stem[:1]
        possible_names = [cache_name, stem + ".jpg", stem + ".png"]

        for base in (
            "special://masterprofile/Thumbnails/",
            "special://profile/Thumbnails/",
        ):
            for name in possible_names:
                data = _read_vfs_file("{}{}/{}".format(base, bucket, name))
                if data:
                    return data

    return None


def read_artwork(image_url):
    if not image_url:
        return None

    data = _read_vfs_file(image_url)
    if data:
        return data

    decoded = _unwrap_image_url(image_url)
    if decoded:
        data = _read_vfs_file(decoded)
        if data:
            return data

        translated = xbmcvfs.translatePath(decoded)
        if translated != decoded:
            data = _read_vfs_file(translated)
            if data:
                return data

    return _read_cached_artwork(image_url)

# -*- coding: utf-8 -*-
from __future__ import annotations

import base64
import hmac
import ipaddress
import json
import mimetypes
import os
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import xbmc
import xbmcaddon
import xbmcvfs

from kodi_state import get_status, read_artwork, admin_action


ADDON = xbmcaddon.Addon()
ADDON_PATH = Path(ADDON.getAddonInfo("path"))
WEB_ROOT = ADDON_PATH / "resources" / "web"

AUDIO_MIME = {
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".mp4": "audio/mp4",
    ".aac": "audio/aac",
    ".flac": "audio/flac",
    ".ogg": "audio/ogg",
    ".oga": "audio/ogg",
    ".opus": "audio/ogg; codecs=opus",
    ".wav": "audio/wav",
    ".wave": "audio/wav",
    ".webm": "audio/webm",
}


def _setting_bool(key, default=False):
    value = ADDON.getSetting(key)
    if value == "":
        return default
    return value.lower() == "true"


def _content_type_for_media(path):
    clean = (path or "").split("?", 1)[0]
    ext = os.path.splitext(clean)[1].lower()
    if ext in AUDIO_MIME:
        return AUDIO_MIME[ext]

    guessed, _ = mimetypes.guess_type(clean)
    if guessed and guessed.startswith("audio/"):
        return guessed

    return "application/octet-stream"


def _parse_range(value, size):
    """
    Parse a single RFC 7233 byte range. Returns (start, end) inclusive.
    Multiple ranges are intentionally not supported.
    """
    if not value or not value.startswith("bytes="):
        return None

    spec = value[6:].strip()
    if "," in spec:
        return None

    try:
        start_s, end_s = spec.split("-", 1)

        if start_s == "":
            # suffix-byte-range-spec: bytes=-500
            suffix = int(end_s)
            if suffix <= 0:
                return None
            suffix = min(suffix, size)
            return max(0, size - suffix), size - 1

        start = int(start_s)
        if start < 0 or start >= size:
            return "unsatisfiable"

        if end_s == "":
            end = size - 1
        else:
            end = min(int(end_s), size - 1)

        if end < start:
            return "unsatisfiable"

        return start, end
    except Exception:
        return None


def _is_local_or_private(address):
    """
    Allow admin access automatically from localhost and private/link-local LAN
    clients. Public/non-local addresses still require the explicit override.
    """
    host = (address or "").split("%", 1)[0]

    try:
        ip = ipaddress.ip_address(host)
        return bool(ip.is_loopback or ip.is_private or ip.is_link_local)
    except ValueError:
        return host in ("localhost",)


def _trusted_proxy_networks():
    """
    Parse configured trusted proxy IPs/CIDR networks.

    Forwarded client-address headers are ignored unless the immediate TCP peer
    matches one of these entries.
    """
    raw = ADDON.getSetting("trusted_proxies") or "127.0.0.1,::1"
    networks = []

    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue

        try:
            networks.append(ipaddress.ip_network(item, strict=False))
        except ValueError:
            xbmc.log(
                "[service.web.radio] Ignoring invalid trusted proxy entry: {!r}".format(item),
                xbmc.LOGWARNING,
            )

    return networks


def _is_trusted_proxy(address):
    host = (address or "").split("%", 1)[0]

    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False

    return any(ip in network for network in _trusted_proxy_networks())


def _forwarded_chain_from_xff(value):
    """
    Return valid IPs from X-Forwarded-For in header order.

    Invalid tokens are ignored rather than treated as addresses.
    """
    result = []

    for token in (value or "").split(","):
        token = token.strip().strip('"')
        if not token:
            continue

        # Handle bracketed IPv6 and the uncommon IPv4:port form.
        if token.startswith("[") and "]" in token:
            token = token[1:token.index("]")]
        else:
            try:
                ipaddress.ip_address(token)
            except ValueError:
                if token.count(":") == 1:
                    possible_host, possible_port = token.rsplit(":", 1)
                    if possible_port.isdigit():
                        token = possible_host

        token = token.split("%", 1)[0]

        try:
            result.append(str(ipaddress.ip_address(token)))
        except ValueError:
            continue

    return result


def _effective_client_ip(peer_address, x_forwarded_for):
    """
    Resolve the real client address without blindly trusting proxy headers.

    If the socket peer is not trusted, return it unchanged.

    If the peer is trusted, walk X-Forwarded-For from right to left, stripping
    trusted proxy hops. The first remaining untrusted address is the client.
    This prevents a remote client from spoofing itself as a private address by
    prepending a forged X-Forwarded-For value.
    """
    peer = (peer_address or "").split("%", 1)[0]

    if not _is_trusted_proxy(peer):
        return peer

    chain = _forwarded_chain_from_xff(x_forwarded_for)
    if not chain:
        return peer

    chain.append(peer)

    while len(chain) > 1 and _is_trusted_proxy(chain[-1]):
        chain.pop()

    return chain[-1] if chain else peer


def _admin_credentials():
    username = ADDON.getSetting("admin_username") or "admin"
    password = ADDON.getSetting("admin_password") or "pass@word1"
    return username, password



def _theaudiodb_album_url(artist, album):
    """
    Resolve artist + album to a TheAudioDB album page using their public
    searchalbum endpoint. This only runs when a user clicks Album Info.
    """
    api_url = (
        "https://www.theaudiodb.com/api/v1/json/123/searchalbum.php?"
        + urllib.parse.urlencode({"s": artist, "a": album})
    )

    request = urllib.request.Request(
        api_url,
        headers={
            "User-Agent": "Kodi-Radio-Station/0.4",
            "Accept": "application/json",
        },
    )

    with urllib.request.urlopen(request, timeout=6) as response:
        payload = json.loads(response.read().decode("utf-8"))

    albums = payload.get("album") or []
    if not albums:
        return ""

    # Prefer an exact case-insensitive match if TheAudioDB returns several.
    chosen = albums[0]
    artist_fold = artist.casefold()
    album_fold = album.casefold()

    for candidate in albums:
        if (
            str(candidate.get("strArtist", "")).casefold() == artist_fold
            and str(candidate.get("strAlbum", "")).casefold() == album_fold
        ):
            chosen = candidate
            break

    album_id = str(chosen.get("idAlbum") or "").strip()
    if not album_id:
        return ""

    return "https://www.theaudiodb.com/album/{}".format(
        urllib.parse.quote(album_id, safe="")
    )


def _album_info_url(artist, album):
    """
    Resolve Album Info through TheAudioDB only.

    There is deliberately no secondary provider. If TheAudioDB cannot resolve
    the album, return an empty result and let the request fail cleanly.
    """
    try:
        return _theaudiodb_album_url(artist, album)
    except Exception as exc:
        xbmc.log(
            "[service.web.radio] TheAudioDB lookup failed: {!r}".format(exc),
            xbmc.LOGWARNING,
        )
        return ""


def _request_base_url(handler):
    host = (handler.headers.get("Host") or "").strip()
    if not host:
        port = ADDON.getSetting("port") or "8000"
        host = "127.0.0.1:{}".format(port)

    proto = "http"
    if _is_trusted_proxy(handler.client_address[0]):
        forwarded_proto = (handler.headers.get("X-Forwarded-Proto") or "").split(",", 1)[0].strip()
        if forwarded_proto in ("http", "https"):
            proto = forwarded_proto

    return "{}://{}".format(proto, host)


def _current_mp3_status():
    status = get_status()
    media_file = (status.get("file") or "").strip()
    is_mp3 = media_file.split("?", 1)[0].lower().endswith(".mp3")
    return status, media_file, is_mp3


def _estimate_mp3_bytes_per_second(status, size):
    try:
        duration = float(status.get("duration") or 0)
        if duration > 0 and size > 0:
            return max(8192.0, float(size) / duration)
    except Exception:
        pass
    return 24000.0


def _mp3_live_offset(status, size):
    """
    Approximate Kodi's current playback position inside an MP3 file.

    This is intentionally approximate because VBR files are not byte-linear.
    A small backoff gives the decoder room to synchronize.
    """
    try:
        duration = float(status.get("duration") or 0)
        position = float(status.get("position") or 0)

        if duration <= 0 or position <= 0 or size <= 0:
            return 0

        ratio = max(0.0, min(0.995, position / duration))
        return max(0, int(size * ratio) - 96 * 1024)
    except Exception:
        return 0


def _find_mp3_frame_sync(handle, start, size):
    """
    Find a plausible MPEG audio frame boundary at/after start.
    """
    if size <= 4:
        return 0

    start = max(0, min(int(start), max(0, size - 4)))

    try:
        handle.seek(start, 0)
    except Exception:
        return 0

    scan_len = min(256 * 1024, size - start)
    data = handle.readBytes(scan_len)
    if not data:
        return start

    for i in range(max(0, len(data) - 4)):
        b0 = data[i]
        b1 = data[i + 1]
        b2 = data[i + 2]

        if b0 != 0xFF or (b1 & 0xE0) != 0xE0:
            continue

        version = (b1 >> 3) & 0x03
        layer = (b1 >> 1) & 0x03
        bitrate_index = (b2 >> 4) & 0x0F
        sample_rate_index = (b2 >> 2) & 0x03

        if version == 0x01:
            continue
        if layer == 0x00:
            continue
        if bitrate_index in (0x00, 0x0F):
            continue
        if sample_rate_index == 0x03:
            continue

        return start + i

    return start


ICY_METAINT = 4096


def _radio_station_name():
    return (ADDON.getSetting("station_name") or "Kodi Radio Station").strip()


def _icy_stream_title(status):
    station = _radio_station_name()
    artist = (status.get("artist") or "").strip()
    title = (status.get("title") or "").strip()

    parts = [station]
    if artist:
        parts.append(artist)
    if title:
        parts.append(title)

    return "-".join(parts)


def _icy_metadata_block(status):
    title = _icy_stream_title(status)
    title = title.replace("\\", "\\\\").replace("'", "\\'")
    payload = ("StreamTitle='{}';".format(title)).encode("utf-8", "replace")

    payload = payload[:255 * 16]
    padding = (-len(payload)) % 16
    padded = payload + (b"\x00" * padding)

    return bytes([len(padded) // 16]) + padded


def _client_wants_icy_metadata(handler):
    return (handler.headers.get("Icy-MetaData") or "").strip() == "1"


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


class RadioRequestHandler(BaseHTTPRequestHandler):
    server_version = "KodiRadioStation/1.0"

    def _client_ip(self):
        return _effective_client_ip(
            self.client_address[0],
            self.headers.get("X-Forwarded-For", ""),
        )

    def log_message(self, fmt, *args):
        xbmc.log(
            "[service.web.radio] HTTP {} - {}".format(
                self._client_ip(), fmt % args
            ),
            xbmc.LOGDEBUG,
        )

    def _admin_allowed_here(self):
        # Use the proxy-resolved address only when the immediate proxy itself
        # is explicitly trusted. Otherwise forwarded headers are ignored.
        client_ip = self._client_ip()

        if _is_local_or_private(client_ip):
            return True

        return _setting_bool("admin_allow_remote", False)

    def _check_admin_auth(self):
        if not self._admin_allowed_here():
            self.send_error(403, "Admin page is restricted to local/private networks")
            return False

        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Basic "):
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Kodi Radio Station Admin"')
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return False

        try:
            decoded = base64.b64decode(auth[6:].strip()).decode("utf-8")
            supplied_user, supplied_pass = decoded.split(":", 1)
        except Exception:
            supplied_user, supplied_pass = "", ""

        expected_user, expected_pass = _admin_credentials()

        ok = (
            hmac.compare_digest(supplied_user, expected_user)
            and hmac.compare_digest(supplied_pass, expected_pass)
        )

        if not ok:
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Kodi Radio Station Admin"')
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return False

        return True

    def _send_bytes(self, code, content_type, body, cache_control="no-store"):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache_control)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _send_embeddable_html(self, body):
        """
        Send only the compact public player as frameable content.

        The normal site/admin responses keep X-Frame-Options: DENY. This route
        deliberately omits X-Frame-Options and permits framing so /compact can
        be embedded in a website iframe.
        """
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "frame-ancestors *")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, payload, code=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send_bytes(code, "application/json; charset=utf-8", body)

    def _stream_current_media(self):
        status = get_status()
        media_file = status.get("file", "")
        if not media_file:
            self.send_error(404, "No audio item is currently available")
            return

        handle = None
        try:
            handle = xbmcvfs.File(media_file, "rb")
            size = int(handle.size())
            if size <= 0:
                self.send_error(404, "Current item has no readable media data")
                return

            parsed_range = _parse_range(self.headers.get("Range"), size)

            if parsed_range == "unsatisfiable":
                self.send_response(416)
                self.send_header("Content-Range", "bytes */{}".format(size))
                self.end_headers()
                return

            if parsed_range:
                start, end = parsed_range
                code = 206
            else:
                start, end = 0, size - 1
                code = 200

            length = end - start + 1
            content_type = _content_type_for_media(media_file)

            if start:
                handle.seek(start, 0)

            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if code == 206:
                self.send_header(
                    "Content-Range",
                    "bytes {}-{}/{}".format(start, end, size),
                )
            self.end_headers()

            remaining = length
            chunk_size = 256 * 1024

            while remaining > 0:
                chunk = handle.readBytes(min(chunk_size, remaining))
                if not chunk:
                    break

                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    break

                remaining -= len(chunk)

        except Exception as exc:
            xbmc.log(
                "[service.web.radio] Stream error: {!r}".format(exc),
                xbmc.LOGERROR,
            )
            try:
                self.send_error(500, "Unable to open the current media item")
            except Exception:
                pass
        finally:
            if handle:
                try:
                    handle.close()
                except Exception:
                    pass

    def _stream_live_mp3(self, head_only=False):
        """
        Continuous MP3 stream tied to Kodi playback, with optional ICY metadata.

        Winamp typically sends Icy-MetaData: 1. When it does, this stream
        interleaves metadata so the title appears as:

            Station Name - Artist Name - Song Name

        A short initial burst fills the client buffer before normal real-time
        pacing begins, reducing repeated buffering/title flicker in Winamp.
        """
        status, media_file, is_mp3 = _current_mp3_status()

        if not status.get("playing") or not media_file:
            self.send_error(404, "Kodi is not currently playing audio")
            return

        if not is_mp3:
            self.send_error(415, "The current Kodi item is not an MP3")
            return

        wants_metadata = _client_wants_icy_metadata(self)
        station_name = _radio_station_name()

        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Cache-Control", "no-cache, no-store")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.send_header("icy-pub", "0")
        if wants_metadata:
            self.send_header("icy-metaint", str(ICY_METAINT))
        self.end_headers()

        if head_only:
            return

        handle = None
        current_token = ""
        bytes_per_second = 24000.0
        last_state_check = 0.0
        current_state = status
        consecutive_state_errors = 0

        audio_until_metadata = ICY_METAINT if wants_metadata else None

        # Allow roughly 2 seconds of audio to be sent quickly at connection
        # start and after each track change. This helps Winamp establish a
        # healthy buffer instead of repeatedly falling into "Buffering".
        burst_bytes_remaining = 0

        try:
            while True:
                now = time.monotonic()

                if handle is None or (now - last_state_check) >= 0.35:
                    try:
                        current_state = get_status()
                        consecutive_state_errors = 0
                    except Exception:
                        consecutive_state_errors += 1
                        if consecutive_state_errors >= 3:
                            break
                        time.sleep(0.15)
                        continue

                    last_state_check = now

                    if not current_state.get("playing"):
                        break

                    new_file = (current_state.get("file") or "").strip()
                    new_token = current_state.get("stream_token") or ""

                    if not new_file:
                        break

                    if not new_file.split("?", 1)[0].lower().endswith(".mp3"):
                        break

                    if new_token != current_token:
                        if handle:
                            try:
                                handle.close()
                            except Exception:
                                pass

                        handle = xbmcvfs.File(new_file, "rb")
                        size = int(handle.size())

                        approx = _mp3_live_offset(current_state, size)
                        sync = _find_mp3_frame_sync(handle, approx, size)

                        try:
                            handle.seek(sync, 0)
                        except Exception:
                            pass

                        bytes_per_second = _estimate_mp3_bytes_per_second(
                            current_state, size
                        )
                        current_token = new_token

                        # Prime Winamp with about two seconds of audio.
                        burst_bytes_remaining = int(bytes_per_second * 8.0)

                    if current_state.get("paused"):
                        time.sleep(0.12)
                        continue

                if handle is None:
                    time.sleep(0.05)
                    continue

                if wants_metadata:
                    to_read = min(4096, audio_until_metadata)
                else:
                    to_read = 4096

                started = time.monotonic()
                chunk = handle.readBytes(to_read)

                if not chunk:
                    try:
                        handle.close()
                    except Exception:
                        pass
                    handle = None
                    current_token = ""
                    last_state_check = 0.0
                    time.sleep(0.03)
                    continue

                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (
                    BrokenPipeError,
                    ConnectionResetError,
                    ConnectionAbortedError,
                ):
                    break

                if wants_metadata:
                    audio_until_metadata -= len(chunk)

                    if audio_until_metadata == 0:
                        try:
                            metadata_state = get_status()
                        except Exception:
                            metadata_state = current_state

                        metadata = _icy_metadata_block(metadata_state)

                        try:
                            self.wfile.write(metadata)
                            self.wfile.flush()
                        except (
                            BrokenPipeError,
                            ConnectionResetError,
                            ConnectionAbortedError,
                        ):
                            break

                        audio_until_metadata = ICY_METAINT

                # During the initial burst, send data without artificial delay.
                if burst_bytes_remaining > 0:
                    burst_bytes_remaining = max(
                        0, burst_bytes_remaining - len(chunk)
                    )
                    continue

                # Keep a small delivery margin above the nominal source
                # bitrate so Winamp's input buffer stays healthy. This is not a
                # second port or transcoder; it only changes pacing.
                effective_rate = max(bytes_per_second * 1.03, 1.0)
                target = len(chunk) / effective_rate
                elapsed = time.monotonic() - started
                if target > elapsed:
                    time.sleep(target - elapsed)

        except Exception as exc:
            xbmc.log(
                "[service.web.radio] live.mp3 stream error: {!r}".format(exc),
                xbmc.LOGERROR,
            )
        finally:
            if handle:
                try:
                    handle.close()
                except Exception:
                    pass

    def _stream_current_mp3_file(self, head_only=False):
        """
        Serve the current MP3 as a normal HTTP media object.

        This is deliberately not a live radio stream. It starts at byte 0 unless
        the client explicitly requests a Range. The existing browser /stream
        implementation is left untouched.
        """
        status, media_file, is_mp3 = _current_mp3_status()

        if not media_file:
            self.send_error(404, "Nothing is currently playing")
            return

        if not is_mp3:
            self.send_error(415, "The current Kodi item is not an MP3")
            return

        handle = None
        try:
            handle = xbmcvfs.File(media_file, "rb")
            size = int(handle.size())

            range_header = self.headers.get("Range")
            start = 0
            end = size - 1
            partial = False

            if range_header:
                parsed = _parse_byte_range(range_header, size)
                if parsed is None:
                    self.send_response(416)
                    self.send_header("Content-Range", "bytes */{}".format(size))
                    self.send_header("Accept-Ranges", "bytes")
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    return

                start, end = parsed
                partial = True

            length = max(0, end - start + 1)

            self.send_response(206 if partial else 200)
            self.send_header("Content-Type", "audio/mpeg")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-store")
            self.send_header(
                "Content-Disposition",
                'inline; filename="current.mp3"',
            )

            if partial:
                self.send_header(
                    "Content-Range",
                    "bytes {}-{}/{}".format(start, end, size),
                )

            self.end_headers()

            if head_only:
                return

            try:
                handle.seek(start, 0)
            except Exception:
                pass

            remaining = length
            while remaining > 0:
                chunk = handle.readBytes(min(64 * 1024, remaining))
                if not chunk:
                    break

                try:
                    self.wfile.write(chunk)
                except (
                    BrokenPipeError,
                    ConnectionResetError,
                    ConnectionAbortedError,
                ):
                    break

                remaining -= len(chunk)

        except Exception as exc:
            xbmc.log(
                "[service.web.radio] current.mp3 error: {!r}".format(exc),
                xbmc.LOGERROR,
            )
            try:
                self.send_error(500, "Could not serve the current MP3")
            except Exception:
                pass
        finally:
            if handle:
                try:
                    handle.close()
                except Exception:
                    pass

    def do_HEAD(self):
        path = urlparse(self.path).path

        if path == "/live.mp3":
            self._stream_live_mp3(head_only=True)
            return

        if path == "/current.mp3":
            self._stream_current_mp3_file(head_only=True)
            return

        if path != "/stream":
            self.send_error(404)
            return

        status = get_status()
        media_file = status.get("file", "")
        if not media_file:
            self.send_error(404)
            return

        handle = None
        try:
            handle = xbmcvfs.File(media_file, "rb")
            size = int(handle.size())
            self.send_response(200)
            self.send_header("Content-Type", _content_type_for_media(media_file))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
        except Exception:
            self.send_error(500)
        finally:
            if handle:
                try:
                    handle.close()
                except Exception:
                    pass

    def do_POST(self):
        path = urlparse(self.path).path

        if path != "/api/admin/control":
            self.send_error(404)
            return

        if not self._check_admin_auth():
            return

        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length <= 0 or length > 65536:
                raise ValueError("Invalid request length")

            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))
            action = payload.get("action")
            value = payload.get("value")

            result = admin_action(action, value)
            self._send_json({"ok": True, "result": result})
        except ValueError as exc:
            self._send_json({"ok": False, "error": str(exc)}, 400)
        except RuntimeError as exc:
            self._send_json({"ok": False, "error": str(exc)}, 409)
        except Exception as exc:
            xbmc.log(
                "[service.web.radio] Admin control error: {!r}".format(exc),
                xbmc.LOGERROR,
            )
            self._send_json(
                {"ok": False, "error": "Unable to execute control."},
                500,
            )

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/api/status":
            try:
                status = get_status()
                thumbnail = status.get("thumbnail", "")
                media_file = status.get("file", "")

                status["station_name"] = (
                    ADDON.getSetting("station_name") or "Kodi Radio Station"
                )
                status["artwork"] = "/art/current" if thumbnail else ""
                status["stream"] = "/stream" if media_file else ""
                status["album_info_available"] = bool(
                    status.get("artist") and status.get("album")
                )
                status["album_info_provider"] = "theaudiodb"

                if _setting_bool("diagnostics", False):
                    status["artwork_source"] = thumbnail
                    status["media_source"] = media_file

                status.pop("thumbnail", None)
                status.pop("file", None)
                self._send_json(status)
            except Exception as exc:
                xbmc.log(
                    "[service.web.radio] Status error: {!r}".format(exc),
                    xbmc.LOGERROR,
                )
                self._send_json(
                    {"error": "Unable to read Kodi player state."},
                    500,
                )
            return

        if path == "/album-info":
            status = get_status()
            artist = (status.get("artist") or "").strip()
            album = (status.get("album") or "").strip()

            if not artist or not album:
                self.send_error(404, "No album information is available for the current item")
                return

            try:
                params = urllib.parse.urlencode({
                    "s": artist,
                    "a": album,
                })

                url = (
                    "https://www.theaudiodb.com/api/v1/json/123/"
                    "searchalbum.php?" + params
                )

                request = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": "Kodi-Radio-Station/1.2.0",
                        "Accept": "application/json",
                    },
                )

                with urllib.request.urlopen(request, timeout=8) as response:
                    payload = json.loads(response.read().decode("utf-8", "replace"))

                albums = payload.get("album") or []
                album_id = None

                artist_l = artist.casefold()
                album_l = album.casefold()

                for item in albums:
                    item_artist = (item.get("strArtist") or "").strip().casefold()
                    item_album = (item.get("strAlbum") or "").strip().casefold()

                    if item_artist == artist_l and item_album == album_l:
                        album_id = item.get("idAlbum")
                        break

                if album_id is None and len(albums) == 1:
                    album_id = albums[0].get("idAlbum")

                if album_id:
                    self.send_response(302)
                    self.send_header(
                        "Location",
                        "https://www.theaudiodb.com/album/{}".format(album_id),
                    )
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    return

                self.send_error(404, "TheAudioDB could not find this album")
                return

            except Exception as exc:
                xbmc.log(
                    "[service.web.radio] TheAudioDB album lookup failed: {!r}".format(exc),
                    xbmc.LOGWARNING,
                )
                self.send_error(502, "TheAudioDB album lookup failed")
                return

        if path == "/live.mp3":
            self._stream_live_mp3(head_only=False)
            return

        if path == "/current.mp3":
            self._stream_current_mp3_file(head_only=False)
            return

        if path == "/winamp.pls":
            base = _request_base_url(self)
            body = (
                "[playlist]\n"
                "NumberOfEntries=1\n"
                "File1={}/live.mp3\n"
                "Title1=\n"
                "Length1=-1\n"
                "Version=2\n"
            ).format(base).encode("utf-8")

            self._send_bytes(
                200,
                "audio/x-scpls; charset=utf-8",
                body,
                cache_control="no-store",
            )
            return

        if path == "/winamp.m3u":
            base = _request_base_url(self)
            body = (
                "#EXTM3U\n"
                "#EXTINF:-1,\n"
                "{}/live.mp3\n"
            ).format(base).encode("utf-8")

            self._send_bytes(
                200,
                "audio/x-mpegurl; charset=utf-8",
                body,
                cache_control="no-store",
            )
            return

        if path == "/api/winamp-debug":
            status, media_file, is_mp3 = _current_mp3_status()
            self._send_json({
                "ok": True,
                "playing": bool(status.get("playing")),
                "paused": bool(status.get("paused")),
                "title": status.get("title") or "",
                "artist": status.get("artist") or "",
                "album": status.get("album") or "",
                "file": media_file,
                "is_mp3": bool(is_mp3),
                "stream_available": bool(status.get("stream_available")),
                "current_mp3_url": _request_base_url(self) + "/current.mp3",
                "live_mp3_url": _request_base_url(self) + "/live.mp3",
                "expected_icy_title": _icy_stream_title(status),
                "icy_metadata_requested": self.headers.get("Icy-MetaData", ""),
                "pls_url": _request_base_url(self) + "/winamp.pls",
                "m3u_url": _request_base_url(self) + "/winamp.m3u",
                "user_agent": self.headers.get("User-Agent", ""),
                "range_header": self.headers.get("Range", ""),
            })
            return

        if path == "/stream":
            self._stream_current_media()
            return

        if path == "/art/current":
            try:
                status = get_status()
                raw = read_artwork(status.get("thumbnail", ""))
                if not raw:
                    self.send_error(404)
                    return

                if raw.startswith(b"\x89PNG\r\n\x1a\n"):
                    content_type = "image/png"
                elif raw.startswith(b"\xff\xd8\xff"):
                    content_type = "image/jpeg"
                elif raw.startswith(b"RIFF") and raw[8:12] == b"WEBP":
                    content_type = "image/webp"
                elif raw.startswith((b"GIF87a", b"GIF89a")):
                    content_type = "image/gif"
                else:
                    content_type = "application/octet-stream"

                self._send_bytes(
                    200, content_type, raw, cache_control="no-cache"
                )
            except Exception as exc:
                xbmc.log(
                    "[service.web.radio] Artwork error: {!r}".format(exc),
                    xbmc.LOGERROR,
                )
                self.send_error(500)
            return

        if path == "/api/health":
            self._send_json({
                "ok": True,
                "addon": "service.web.radio",
                "version": ADDON.getAddonInfo("version"),
                "audio_streaming": True,
            })
            return


        if path in ("/compact", "/compact/"):
            candidate = WEB_ROOT / "compact.html"
            self._send_embeddable_html(candidate.read_bytes())
            return

        if path in ("/admin", "/admin/"):
            if not self._check_admin_auth():
                return
            candidate = WEB_ROOT / "admin.html"
            body = candidate.read_bytes()
            self._send_bytes(
                200,
                "text/html; charset=utf-8",
                body,
                cache_control="no-store",
            )
            return

        if path == "/admin.js":
            if not self._check_admin_auth():
                return
            candidate = WEB_ROOT / "admin.js"
            body = candidate.read_bytes()
            self._send_bytes(
                200,
                "application/javascript; charset=utf-8",
                body,
                cache_control="no-store",
            )
            return

        if path in ("/", "/index.html"):
            relative = "index.html"
        else:
            relative = path.lstrip("/")

        if ".." in Path(relative).parts:
            self.send_error(403)
            return

        candidate = (WEB_ROOT / relative).resolve()
        try:
            candidate.relative_to(WEB_ROOT.resolve())
        except ValueError:
            self.send_error(403)
            return

        if not candidate.is_file():
            self.send_error(404)
            return

        body = candidate.read_bytes()
        content_type, _ = mimetypes.guess_type(str(candidate))
        if not content_type:
            content_type = "application/octet-stream"
        if content_type.startswith("text/") or content_type in (
            "application/javascript",
            "application/json",
        ):
            content_type += "; charset=utf-8"

        self._send_bytes(
            200, content_type, body, cache_control="no-cache"
        )


class RadioServer:
    def __init__(self):
        self.httpd = None
        self.thread = None

        remote = _setting_bool("allow_remote", True)
        configured = ADDON.getSetting("bind_address").strip()
        self.bind_address = configured or (
            "0.0.0.0" if remote else "127.0.0.1"
        )

        try:
            self.port = int(ADDON.getSetting("port") or "8000")
        except ValueError:
            self.port = 8088

    def start(self):
        self.httpd = ReusableThreadingHTTPServer(
            (self.bind_address, self.port),
            RadioRequestHandler,
        )
        self.thread = threading.Thread(
            target=self.httpd.serve_forever,
            name="KodiRadioHTTP",
            daemon=True,
        )
        self.thread.start()

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None

const station = document.getElementById("station");
const title = document.getElementById("title");
const album = document.getElementById("album");
const artist = document.getElementById("artist");
const genre = document.getElementById("genre");
const elapsed = document.getElementById("elapsed");
const remaining = document.getElementById("remaining");
const progress = document.getElementById("progress");
const art = document.getElementById("art");
const artPlaceholder = document.getElementById("artPlaceholder");
const playButton = document.getElementById("playButton");
const playSymbol = document.getElementById("playSymbol");
const radioAudio = document.getElementById("radioAudio");
const albumInfoLink = document.getElementById("albumInfoLink");

let lastArtworkKey = "";
let lastStreamToken = "";
let latestStatus = null;
let listenerEnabled = false;
let pendingSeek = null;
let lastSyncAt = 0;

function formatTime(seconds) {
    seconds = Math.max(0, Math.round(Number(seconds) || 0));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
        return `${hours}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    return `${minutes}:${String(secs).padStart(2, "0")}`;
}

function setText(element, value) {
    element.textContent = value || "";
}

function updateArtwork(hasArtwork, key) {
    if (!hasArtwork) {
        art.removeAttribute("src");
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
        lastArtworkKey = "";
        return;
    }

    if (key !== lastArtworkKey) {
        art.src = `/art/current?t=${Date.now()}`;
        lastArtworkKey = key;
    }

    art.onload = () => {
        art.style.display = "block";
        artPlaceholder.style.display = "none";
    };

    art.onerror = () => {
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
    };
}

function updateButton() {
    const available = Boolean(latestStatus && latestStatus.stream_available);
    playButton.disabled = !available;

    if (!available) {
        playButton.title = "No playable Kodi audio item is available";
        playSymbol.textContent = "▶";
        return;
    }

    playButton.title = listenerEnabled ? "Stop listening" : "Listen live";
    playSymbol.textContent = listenerEnabled ? "❚❚" : "▶";
}

function loadCurrentStream(status, autoplay) {
    if (!status || !status.stream_available || !status.stream_token) {
        radioAudio.pause();
        radioAudio.removeAttribute("src");
        lastStreamToken = "";
        return;
    }

    lastStreamToken = status.stream_token;
    pendingSeek = Math.max(0, Number(status.position) || 0);

    // Token prevents the browser from reusing the previous track.
    radioAudio.src = `/stream?track=${encodeURIComponent(status.stream_token)}&t=${Date.now()}`;
    radioAudio.load();

    if (autoplay) {
        const attempt = radioAudio.play();
        if (attempt && typeof attempt.catch === "function") {
            attempt.catch((err) => console.warn("Browser blocked audio playback:", err));
        }
    }
}

radioAudio.addEventListener("loadedmetadata", () => {
    if (pendingSeek !== null && Number.isFinite(pendingSeek)) {
        try {
            // Avoid seeking beyond what the browser reports for odd files.
            const target = Number.isFinite(radioAudio.duration)
                ? Math.min(pendingSeek, Math.max(0, radioAudio.duration - 0.15))
                : pendingSeek;
            radioAudio.currentTime = target;
        } catch (err) {
            console.warn("Initial live seek failed:", err);
        }
    }
    pendingSeek = null;

    if (listenerEnabled && radioAudio.paused) {
        radioAudio.play().catch(() => {});
    }
});

radioAudio.addEventListener("ended", () => {
    // Polling will normally load the next Kodi track. Keeping the listener
    // enabled makes the transition automatic.
    if (listenerEnabled && latestStatus &&
        latestStatus.stream_token &&
        latestStatus.stream_token !== lastStreamToken) {
        loadCurrentStream(latestStatus, true);
    }
});

radioAudio.addEventListener("error", () => {
    if (listenerEnabled) {
        console.warn("Browser could not decode or retrieve the current audio item.");
    }
});

playButton.addEventListener("click", async () => {
    if (!latestStatus || !latestStatus.stream_available) {
        return;
    }

    if (!listenerEnabled) {
        listenerEnabled = true;
        loadCurrentStream(latestStatus, false);

        try {
            await radioAudio.play();
        } catch (err) {
            console.warn("Playback could not start:", err);
        }
    } else {
        listenerEnabled = false;
        radioAudio.pause();
    }

    updateButton();
});

function syncListenerToKodi(status) {
    if (!listenerEnabled || !status || !status.stream_available) {
        return;
    }

    if (status.stream_token !== lastStreamToken) {
        loadCurrentStream(status, true);
        return;
    }

    // Kodi pause is mirrored by the browser listener.
    if (status.paused && !radioAudio.paused) {
        radioAudio.pause();
    } else if (!status.paused && radioAudio.paused && radioAudio.src) {
        radioAudio.play().catch(() => {});
    }

    // Correct meaningful drift, but do not continuously fight the browser.
    const now = Date.now();
    if (!status.paused &&
        radioAudio.readyState >= 1 &&
        now - lastSyncAt > 5000) {
        const kodiPos = Number(status.position) || 0;
        const drift = radioAudio.currentTime - kodiPos;

        if (Math.abs(drift) > 2.5) {
            try {
                radioAudio.currentTime = Math.max(0, kodiPos);
            } catch (_) {}
        }
        lastSyncAt = now;
    }
}

async function refresh() {
    try {
        const response = await fetch("/api/status", { cache: "no-store" });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const s = await response.json();
        latestStatus = s;

        station.textContent = s.station_name || "Kodi Radio Station";

        if (!s.playing) {
            title.textContent = "Nothing playing";
            setText(album, "");
            setText(artist, "");
            setText(genre, "");
            elapsed.textContent = "0:00";
            remaining.textContent = "0:00";
            progress.style.width = "0%";
            updateArtwork(false, "");
            albumInfoLink.hidden = true;
            document.title = station.textContent;

            if (listenerEnabled) {
                radioAudio.pause();
                radioAudio.removeAttribute("src");
                lastStreamToken = "";
            }

            updateButton();
            return;
        }

        title.textContent = s.title || "Unknown title";
        setText(album, s.album);
        setText(artist, s.artist);
        setText(genre, s.genre);

        elapsed.textContent = formatTime(s.position);
        remaining.textContent = `-${formatTime(Math.max(0, s.duration - s.position))}`;

        let pct = Number(s.percentage);
        if (!Number.isFinite(pct) && s.duration > 0) {
            pct = (s.position / s.duration) * 100;
        }
        pct = Math.min(100, Math.max(0, Number.isFinite(pct) ? pct : 0));
        progress.style.width = `${pct}%`;

        const artworkKey = `${s.title}|${s.artist}|${s.album}`;
        updateArtwork(Boolean(s.artwork), artworkKey);

        albumInfoLink.hidden = !s.album_info_available;
        albumInfoLink.title = s.album_info_available
            ? `Open album information (${s.album_info_provider || "provider"})`
            : "";

        document.title = `${s.title || "Now Playing"} — ${station.textContent}`;

        updateButton();
        syncListenerToKodi(s);
    } catch (error) {
        title.textContent = "Kodi Radio Station unavailable";
        latestStatus = null;
        playButton.disabled = true;
        console.error(error);
    }
}

refresh();
setInterval(refresh, 1000);

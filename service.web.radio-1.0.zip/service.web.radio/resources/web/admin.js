const station = document.getElementById("station");
const title = document.getElementById("title");
const album = document.getElementById("album");
const artist = document.getElementById("artist");
const genre = document.getElementById("genre");
const elapsed = document.getElementById("elapsed");
const remaining = document.getElementById("remaining");
const art = document.getElementById("art");
const artPlaceholder = document.getElementById("artPlaceholder");

const previousButton = document.getElementById("previousButton");
const playPauseButton = document.getElementById("playPauseButton");
const stopButton = document.getElementById("stopButton");
const nextButton = document.getElementById("nextButton");
const muteButton = document.getElementById("muteButton");
const shuffleButton = document.getElementById("shuffleButton");
const repeatAll = document.getElementById("repeatAll");
const repeatSong = document.getElementById("repeatSong");

const seek = document.getElementById("seek");
const volume = document.getElementById("volume");
const volumeValue = document.getElementById("volumeValue");
const albumInfoLink = document.getElementById("albumInfoLink");

let latestStatus = null;
let lastArtworkKey = "";
let draggingSeek = false;
let draggingVolume = false;

function formatTime(seconds) {
    seconds = Math.max(0, Math.round(Number(seconds) || 0));
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
        return `${hours}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    return `${minutes}:${String(secs).padStart(2, "0")}`;
}

function setText(element, value) {
    element.textContent = value || "";
}

function updateArtwork(hasArtwork, key) {
    if (!hasArtwork) {
        art.removeAttribute("src");
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
        lastArtworkKey = "";
        return;
    }

    if (key !== lastArtworkKey) {
        art.src = `/art/current?t=${Date.now()}`;
        lastArtworkKey = key;
    }

    art.onload = () => {
        art.style.display = "block";
        artPlaceholder.style.display = "none";
    };

    art.onerror = () => {
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
    };
}

async function command(action, value = null) {
    const response = await fetch("/api/admin/control", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        cache: "no-store",
        body: JSON.stringify({action, value}),
    });

    if (!response.ok) {
        const text = await response.text();
        throw new Error(text || `HTTP ${response.status}`);
    }

    await refresh();
}

previousButton.addEventListener("click", () => command("previous").catch(console.error));
playPauseButton.addEventListener("click", () => command("playpause").catch(console.error));
stopButton.addEventListener("click", () => command("stop").catch(console.error));
nextButton.addEventListener("click", () => command("next").catch(console.error));
muteButton.addEventListener("click", () => command("mute").catch(console.error));
shuffleButton.addEventListener("click", () => command("shuffle").catch(console.error));

function setRepeatMode(mode) {
    const current = latestStatus?.repeat || "off";
    command("repeat", current === mode ? "off" : mode).catch(console.error);
}

repeatAll.addEventListener("click", () => setRepeatMode("all"));
repeatSong.addEventListener("click", () => setRepeatMode("one"));

seek.addEventListener("pointerdown", () => { draggingSeek = true; });
seek.addEventListener("pointerup", () => {
    draggingSeek = false;
    command("seek", Number(seek.value)).catch(console.error);
});
seek.addEventListener("change", () => {
    if (!draggingSeek) {
        command("seek", Number(seek.value)).catch(console.error);
    }
});

volume.addEventListener("pointerdown", () => { draggingVolume = true; });
volume.addEventListener("input", () => {
    volumeValue.textContent = `${Math.round(Number(volume.value))}%`;
});
volume.addEventListener("pointerup", () => {
    draggingVolume = false;
    command("volume", Number(volume.value)).catch(console.error);
});
volume.addEventListener("change", () => {
    if (!draggingVolume) {
        command("volume", Number(volume.value)).catch(console.error);
    }
});

async function refresh() {
    try {
        const response = await fetch("/api/status", {cache: "no-store"});
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const s = await response.json();
        latestStatus = s;

        station.textContent = s.station_name || "Kodi Radio Station";

        if (!s.playing) {
            title.textContent = "Nothing playing";
            setText(album, "");
            setText(artist, "");
            setText(genre, "");
            elapsed.textContent = "0:00";
            remaining.textContent = "0:00";
            seek.value = 0;
            updateArtwork(false, "");
            albumInfoLink.hidden = true;
            playPauseButton.textContent = "▶";
            previousButton.disabled = true;
            stopButton.disabled = true;
            nextButton.disabled = true;
        } else {
            title.textContent = s.title || "Unknown title";
            setText(album, s.album);
            setText(artist, s.artist);
            setText(genre, s.genre);

            elapsed.textContent = formatTime(s.position);
            remaining.textContent = `-${formatTime(Math.max(0, s.duration - s.position))}`;

            if (!draggingSeek) {
                seek.value = Number.isFinite(Number(s.percentage)) ? Number(s.percentage) : 0;
            }

            const artworkKey = `${s.title}|${s.artist}|${s.album}`;
            updateArtwork(Boolean(s.artwork), artworkKey);

            albumInfoLink.hidden = !s.album_info_available;
            albumInfoLink.title = s.album_info_available
                ? `Open album information (${s.album_info_provider || "provider"})`
                : "";

            playPauseButton.textContent = s.paused ? "▶" : "❚❚";
            previousButton.disabled = false;
            stopButton.disabled = false;
            nextButton.disabled = false;
        }

        if (!draggingVolume) {
            volume.value = Number(s.volume ?? 0);
            volumeValue.textContent = `${Math.round(Number(s.volume ?? 0))}%`;
        }

        muteButton.textContent = s.muted ? "🔇" : "🔊";
        muteButton.classList.toggle("active", Boolean(s.muted));

        shuffleButton.classList.toggle("active", Boolean(s.shuffle));

        const repeatMode = s.repeat || "off";
        repeatAll.classList.toggle("active", repeatMode === "all");
        repeatSong.classList.toggle("active", repeatMode === "one");

        document.title = `${s.title || "Admin"} — ${station.textContent}`;
    } catch (error) {
        title.textContent = "Kodi Radio Station unavailable";
        console.error(error);
    }
}

refresh();
setInterval(refresh, 750);

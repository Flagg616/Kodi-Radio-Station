const art = document.getElementById("compactArt");
const artPlaceholder = document.getElementById("compactArtPlaceholder");
const title = document.getElementById("compactTitle");
const album = document.getElementById("compactAlbum");
const artist = document.getElementById("compactArtist");
const genre = document.getElementById("compactGenre");
const separator = document.getElementById("compactSeparator");
const albumInfo = document.getElementById("compactAlbumInfo");
const playButton = document.getElementById("compactPlayButton");
const playSymbol = document.getElementById("compactPlaySymbol");
const audio = document.getElementById("compactAudio");

let latestStatus = null;
let listenerEnabled = false;
let lastStreamToken = "";
let lastArtworkKey = "";
let pendingSeek = null;
let lastSyncAt = 0;

function text(el, value) {
    const clean = value || "";
    el.textContent = clean;
    el.title = clean;
}

function updateArtwork(status) {
    const hasArtwork = Boolean(status && status.artwork);
    const key = hasArtwork ? `${status.stream_token || ""}|${status.artwork}` : "";

    if (!hasArtwork) {
        art.removeAttribute("src");
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
        lastArtworkKey = "";
        return;
    }

    if (key !== lastArtworkKey) {
        art.src = `/art/current?t=${Date.now()}`;
        lastArtworkKey = key;
    }

    art.onload = () => {
        art.style.display = "block";
        artPlaceholder.style.display = "none";
    };

    art.onerror = () => {
        art.style.display = "none";
        artPlaceholder.style.display = "grid";
    };
}

function updateButton() {
    const available = Boolean(latestStatus && latestStatus.stream_available);
    playButton.disabled = !available;

    if (!available) {
        playSymbol.textContent = "▶";
        playButton.title = "No playable audio item is available";
        playButton.setAttribute("aria-label", "No playable audio item is available");
        return;
    }

    if (listenerEnabled) {
        playSymbol.textContent = "❚❚";
        playButton.title = "Pause";
        playButton.setAttribute("aria-label", "Pause");
    } else {
        playSymbol.textContent = "▶";
        playButton.title = "Listen live";
        playButton.setAttribute("aria-label", "Listen live");
    }
}

function loadStream(status, autoplay) {
    if (!status || !status.stream_available || !status.stream_token) {
        audio.pause();
        audio.removeAttribute("src");
        lastStreamToken = "";
        pendingSeek = null;
        return;
    }

    lastStreamToken = status.stream_token;
    pendingSeek = Math.max(0, Number(status.position) || 0);

    audio.src = `/stream?track=${encodeURIComponent(status.stream_token)}&t=${Date.now()}`;
    audio.load();

    if (autoplay) {
        audio.play().catch(() => {});
    }
}

audio.addEventListener("loadedmetadata", () => {
    if (pendingSeek !== null && Number.isFinite(pendingSeek)) {
        try {
            const target = Number.isFinite(audio.duration)
                ? Math.min(pendingSeek, Math.max(0, audio.duration - 0.15))
                : pendingSeek;
            audio.currentTime = target;
        } catch (_) {}
    }

    pendingSeek = null;

    if (listenerEnabled && audio.paused) {
        audio.play().catch(() => {});
    }
});

playButton.addEventListener("click", async () => {
    if (!latestStatus || !latestStatus.stream_available) {
        return;
    }

    if (!listenerEnabled) {
        listenerEnabled = true;

        if (!audio.src || lastStreamToken !== latestStatus.stream_token) {
            loadStream(latestStatus, false);
        }

        try {
            await audio.play();
        } catch (_) {}
    } else {
        listenerEnabled = false;
        audio.pause();
    }

    updateButton();
});

function syncToKodi(status) {
    if (!listenerEnabled || !status || !status.stream_available) {
        return;
    }

    if (status.stream_token && status.stream_token !== lastStreamToken) {
        loadStream(status, true);
        return;
    }

    if (status.paused) {
        if (!audio.paused) {
            audio.pause();
        }
        return;
    }

    if (audio.paused) {
        audio.play().catch(() => {});
    }

    const now = Date.now();
    if (now - lastSyncAt < 3000 || audio.readyState < 1) {
        return;
    }

    lastSyncAt = now;
    const kodiPosition = Number(status.position) || 0;
    const drift = Math.abs((Number(audio.currentTime) || 0) - kodiPosition);

    if (drift > 2.5) {
        try {
            audio.currentTime = kodiPosition;
        } catch (_) {}
    }
}

function render(status) {
    latestStatus = status;

    text(title, status.title || "Nothing playing");
    text(album, status.album || "");
    text(artist, status.artist || "");
    text(genre, status.genre || "");

    separator.hidden = !(status.artist && status.genre);
    albumInfo.hidden = !status.album_info_available;

    updateArtwork(status);
    updateButton();
    syncToKodi(status);
}

async function refresh() {
    try {
        const response = await fetch(`/api/status?t=${Date.now()}`, {
            cache: "no-store"
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        render(await response.json());
    } catch (_) {
        text(title, "Station unavailable");
        text(album, "");
        text(artist, "");
        text(genre, "");
        separator.hidden = true;
        albumInfo.hidden = true;
        latestStatus = null;
        updateButton();
    }
}

refresh();
setInterval(refresh, 1000);

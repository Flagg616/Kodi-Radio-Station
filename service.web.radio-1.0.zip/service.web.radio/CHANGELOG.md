# Changelog

## 1.2.9 — 2026-09-13

- Increased initial Winamp buffer burst from ~2 seconds to ~8 seconds.
- Reduced ICY metadata interval from 16384 to 4096 bytes.
- Added a small 3% stream-delivery margin to reduce buffer underruns.
- Dynamic title remains `StationTitle-ArtistName-SongName`.
- No additional network port required.

## 1.2.8 — 2026-09-13

- Suppressed Winamp's `(live.mp3)` fallback suffix.

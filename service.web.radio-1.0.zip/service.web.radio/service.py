# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
from pathlib import Path

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PATH = Path(ADDON.getAddonInfo("path"))
LIB_PATH = ADDON_PATH / "resources" / "lib"

if str(LIB_PATH) not in sys.path:
    sys.path.insert(0, str(LIB_PATH))

from server import RadioServer  # noqa: E402


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[service.web.radio] {}".format(message), level)


def main():
    monitor = xbmc.Monitor()
    server = RadioServer()

    try:
        server.start()
        log("Kodi Radio Station HTTP server started on {}:{}".format(
            server.bind_address, server.port
        ))

        while not monitor.abortRequested():
            if monitor.waitForAbort(1.0):
                break
    except Exception as exc:
        log("Fatal service error: {!r}".format(exc), xbmc.LOGERROR)
    finally:
        server.stop()
        log("Kodi Radio Station service stopped.")


if __name__ == "__main__":
    main()
